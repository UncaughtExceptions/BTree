package com.lizhenpeng.btree.core;

import java.util.ArrayList;
import java.util.List;

/**
 * B树实现类
 * @author 出门左转
 */
@SuppressWarnings("all")
public class BTree<T extends Comparable<T>> {
	
	/**
	 * Rank为B树的阶,B树的阶通常是指B树中子节点的数量
	 */
	public static final int Rank = 10;
	
	/**
	 * KeySize为B树中允许关键字数量最大数量
	 */
	public static final int keySize = Rank - 1;
	
	/**
	 * B树非根节点最小关键字数量
	 */
	public static final int leastKeySize = (int)Math.floor(((float)Rank)/2) - 1;
	
	/**
	 * B树节点分裂时位于关键字列表中的位置
	 */
	public static final int middleIndex = (int)Math.ceil(((float)BTree.keySize)/2) - 1;
	
	/**
	 * 指向B树的根节点
	 * 任何对B树的搜索操作都是从根节点开始,当根节点分裂时需要重新进行引用
	 */
	private TreeNode<T> root;
	
	/**
	 * 初始化B树的根节点
	 * 任何对B树的操作多是从根节点开始
	 */
	public BTree() {
		root = new TreeNode<T>();
	}
	
	/**
	 * 查询树中是否存在指定的关键字
	 * @param key
	 * @return
	 */
	public boolean containKey(T key) {
		if(root == null) {
			throw new RuntimeException("Root Is Null");
		}
		if(key == null) {
			throw new RuntimeException("Key Is Null");
		}
		return containKeyWord(root,key);
	}
	
	/**
	 * 判断指定B树中节点及其子树中是否含有指定的关键字
	 * @param treeNode
	 * @param key
	 * @return
	 */
	public boolean containKeyWord(TreeNode<T> treeNode,T key) {
		if(treeNode == null) {
			return false;
		}
		int compareIndex = 0;
		while(compareIndex < treeNode.getKeyWordSize() && 
				key.compareTo(treeNode.getKeyWords()[compareIndex]) > 0) {
			compareIndex++;
		}
		if(compareIndex < treeNode.getKeyWordSize() && 
				key.compareTo(treeNode.getKeyWords()[compareIndex]) == 0) {
			return true;
		}
		return containKeyWord(treeNode.getSubTree()[compareIndex],key);
	}
	
	
	/**
	 * 返回B树的高度
	 * @return
	 */
	public int getBtreeHeight() {
		if(root == null) {
			throw new RuntimeException("Root Is Null");
		}
		if(root.getKeyWordSize() <= 0) {
			return 0;
		}
		return getTreeDeep(root);
	}
	
	/**
	 * 递归计算树的深度
	 * @param treeNode
	 * @return
	 */
	private int getTreeDeep(TreeNode<T> treeNode) {
		if(treeNode != null) {
			return getTreeDeep(treeNode.getSubTree()[0]) + 1;
		}
		return 0;
	}
	
	/**
	 * 先序遍历B树
	 * 先序遍历时为升序遍历
	 */
	public void search(Forfex<T> forfex) {
		if(root == null) {
			throw new RuntimeException("Root Is Null");
		}
		searchBtree(forfex,root);
	}
	
	/**
	 * 查询关键字并返回关键字所在的节点
	 * @param treeNode
	 * @param key
	 * @return
	 */
	private TreeNode<T> searchTreeNode(TreeNode<T> treeNode,T key){
		int compareIndex = 0;
		//当前B树中不存在该关键字
		if(treeNode == null) {
			return null;
		}
		while(compareIndex < treeNode.getKeyWordSize() && 
				key.compareTo(treeNode.getKeyWords()[compareIndex]) > 0) {
			compareIndex++;
		}
		//寻找到指定的关键字
		if(compareIndex < treeNode.getKeyWordSize() && 
				key.compareTo(treeNode.getKeyWords()[compareIndex]) == 0) {
			return treeNode;
		}
		return searchTreeNode(treeNode.getSubTree()[compareIndex],key);
	}
	
	/**
	 * 查找前驱节点,B树合并时需要判断左右两颗子树节点数量
	 * 如果节点数量>BTree.leastKeySize需要使用前驱或者后继替换根元素
	 * @param treeNode
	 * @return
	 */
	private TreeNode<T> findPrecursorNode(TreeNode<T> treeNode){
		if(treeNode == null) {
			return null;
		}
		if(treeNode.isLeaf()) {
			return treeNode;
		}
		return findPrecursorNode(treeNode.getSubTree()[treeNode.getKeyWordSize()]);
	}
	
	/**
	 * 查找后继,B树合并时需要判断左右两颗子树节点数量
	 * 如果节点数量>BTree.leastKeySize需要使用前驱或者后继替换根元素
	 * @param treeNode
	 * @return
	 */
	private TreeNode<T> findSubsequenceNode(TreeNode<T> treeNode){
		if(treeNode == null) {
			return null;
		}
		if(treeNode.isLeaf()) {
			return treeNode;
		}
		return findPrecursorNode(treeNode.getSubTree()[0]);
	}
	
	/**
	 * B树中添加的关键字
	 * @return
	 */
	public boolean addKeyWord(T key) {
		if(containKey(key)) {
			return false;
		}
		//根节点满则分裂根节点
		if(root.isFull()) {
			TreeNode<T> currentNode = root;
			TreeNode<T> allocateTreeNode = new TreeNode<>();
			root = allocateTreeNode;
			allocateTreeNode.getSubTree()[0] = currentNode;
			splitTreeNode(allocateTreeNode,0);
		}
		insert(root, key);
		return true;
	}
	
	/**
	 * 添加关键字
	 */
	private void insert(TreeNode<T> treeNode,T keyWord) {
		if(treeNode.isLeaf()) {
			treeNode.addKeyWord(keyWord);
		}else {
			int compareIndex = 0;
			while(compareIndex < treeNode.getKeyWordSize() && keyWord.compareTo(treeNode.getKeyWords()[compareIndex]) > 0) {
				compareIndex++;
			}
			//节点如果已满,则提前分裂
			if(treeNode.getSubTree()[compareIndex].isFull()) {
				splitTreeNode(treeNode,compareIndex);
				if(keyWord.compareTo(treeNode.getKeyWords()[compareIndex]) > 0) {
					compareIndex++;
				}
			}
			insert(treeNode.getSubTree()[compareIndex],keyWord);
		}
	}
	
	/**
	 * 分裂B树的孩子节点
	 */
	private void splitTreeNode(TreeNode<T> treeNode,int subTreeIndex) {
		TreeNode<T> subTree = treeNode.getSubTree()[subTreeIndex];
		//获取子树的中间值
		T middleValue = subTree.getKeyWords()[BTree.middleIndex];
		TreeNode<T> leftChild = subTree.clipLeftSubTree();
		TreeNode<T> rightChild = subTree.clipRightSubTree();
		//父节点移动
		treeNode.shiftNodePosition(subTreeIndex);
		treeNode.getKeyWords()[subTreeIndex] = middleValue;
		//重新赋值
		treeNode.getSubTree()[subTreeIndex] = leftChild;
		treeNode.getSubTree()[subTreeIndex + 1] = rightChild;
		leftChild.setParentNode(treeNode);
		rightChild.setParentNode(treeNode);
	}
	
	/**
	 * B树中删除指定的关键字
	 * B树删除关键字可以发生在任意的节点位置
	 * @param key
	 */
	public void removeKeyWord(T key) {
		if(root == null || root.getKeyWordSize() == 0) {
			return;
		}
		if(key == null) {
			throw new RuntimeException("KeyWord Is Null");
		}
		deleteKeyWord(root,key);
	}
	
	/**
	 * 从指定的节点搜索对应的关键字并且删除
	 * B
	 * @param treeNode
	 * @param key
	 */
	private void deleteKeyWord(TreeNode<T> treeNode,T key) {
		//关键字位于叶子节点直接删除                                     
		if(treeNode.isLeaf()) {
			treeNode.removeKeyWord(key);
		}else {
			int compareIndex = 0;
			while(compareIndex < treeNode.getKeyWordSize() && 
					key.compareTo(treeNode.getKeyWords()[compareIndex]) > 0) {
				compareIndex++;
			}
			//关键字位于内部节点
			if(compareIndex < treeNode.getKeyWordSize() && 
					key.compareTo(treeNode.getKeyWords()[compareIndex]) == 0) {
				TreeNode<T> leftChild = treeNode.getSubTree()[compareIndex];
				TreeNode<T> rightChild = treeNode.getSubTree()[compareIndex + 1];
				//查询前驱
				if(leftChild.getKeyWordSize() > BTree.leastKeySize) {
					TreeNode<T> prevTreeNode = findPrecursorNode(leftChild);
					T maxValue = prevTreeNode.getKeyWords()[prevTreeNode.getKeyWordSize() - 1];
					treeNode.getKeyWords()[compareIndex] = maxValue;
					deleteKeyWord(leftChild,maxValue);
					return;
				}
				//查找后继
				if(rightChild.getKeyWordSize() > BTree.leastKeySize) {
					TreeNode<T> nextTreeNode = findSubsequenceNode(rightChild);
					T minValue = nextTreeNode.getKeyWords()[0]; 
					treeNode.getKeyWords()[compareIndex] = minValue;
					deleteKeyWord(rightChild,minValue);
					return;
				}
				//合并节点
				T value = treeNode.getKeyWords()[compareIndex];
				leftChild.addKeyWord(value);
				//添加右子树
				int subTreeIndex = leftChild.getKeyWordSize();
				int rightTreeIndex = 0;
				for(; rightTreeIndex < rightChild.getKeyWordSize(); rightTreeIndex++) {
					leftChild.addKeyWord(rightChild.getKeyWords()[rightTreeIndex]);
					leftChild.getSubTree()[subTreeIndex++] = rightChild.getSubTree()[rightTreeIndex];
				}
				//复制最后一个子树
				leftChild.getSubTree()[subTreeIndex] = rightChild.getSubTree()[rightTreeIndex];
				treeNode.removeKeyWord(value);
				//判断是为根节点
				if(treeNode == root && treeNode.getKeyWordSize() == 0) {
					leftChild.setParentNode(null);
					//重新引用根节点
					root = leftChild;
				}
				deleteKeyWord(leftChild, key);
			//关键字位于子树中
			}else {
				//判断子树关键字数量
				TreeNode<T> subTree = treeNode.getSubTree()[compareIndex];			
				if(subTree.getKeyWordSize() > BTree.leastKeySize) {
					deleteKeyWord(subTree, key);
					return;
				}
				//获取左兄弟节点,右旋
				if(compareIndex > 0) {
					TreeNode<T> leftBrother = treeNode.getSubTree()[compareIndex -1];
					//判断左兄弟关键字数量
					if(leftBrother.getKeyWordSize() > BTree.leastKeySize) {
						//获取父节点值
						T parentNodeValue = treeNode.getKeyWords()[compareIndex - 1];
						T maxValue = leftBrother.getKeyWords()[leftBrother.getKeyWordSize() - 1];
						TreeNode<T> leftBrotherChild = leftBrother.getSubTree()[leftBrother.getKeyWordSize()];
						//节点整体右移动一个单位
						subTree.rightWardMove();
						//调整节点值
						subTree.getKeyWords()[0] = parentNodeValue;
						subTree.getSubTree()[0] = leftBrotherChild;
						if(leftBrotherChild != null) {
							leftBrotherChild.setParentNode(subTree);
						}
						treeNode.getKeyWords()[compareIndex - 1] = maxValue;
						//左兄弟删除指定的节点
						leftBrother.removeKeyWord(maxValue);
						deleteKeyWord(subTree,key);
						return;
					}
				}
				//获取右兄弟节点,左旋
				if(compareIndex < treeNode.getKeyWordSize()) {
					TreeNode<T> rightBrother = treeNode.getSubTree()[compareIndex + 1];
					if(rightBrother.getKeyWordSize() > BTree.leastKeySize) {
						//右节点最小值
						T minValue = rightBrother.getKeyWords()[0];
						TreeNode<T> righBrotherChild = rightBrother.getSubTree()[0];
						//调整节点值
						subTree.addKeyWord(treeNode.getKeyWords()[compareIndex]);
						subTree.getSubTree()[subTree.getKeyWordSize()] = righBrotherChild;
						if(righBrotherChild != null) {
							righBrotherChild.setParentNode(subTree);
						}
						treeNode.getKeyWords()[compareIndex] = minValue;
						//节点整体左移动
						rightBrother.leftWardMove();
						deleteKeyWord(subTree,key);
						return;
					}
				}
				//合并节点
				TreeNode<T> leftChild = null;
				TreeNode<T> rightChild = null;
				T value = null;
				//左子树为根节点进行合并
				if(compareIndex < treeNode.getKeyWordSize()) {
					leftChild = treeNode.getSubTree()[compareIndex];
					rightChild = treeNode.getSubTree()[compareIndex + 1];
					value = treeNode.getKeyWords()[compareIndex];
				}else {
					leftChild = treeNode.getSubTree()[compareIndex - 1];
					rightChild = treeNode.getSubTree()[compareIndex];
					value = treeNode.getKeyWords()[compareIndex - 1];
				}
				leftChild.addKeyWord(value);
				int subTreeStartIndex = leftChild.getKeyWordSize();
				int index = 0;
				for(; index < rightChild.getKeyWordSize(); index++) {
					leftChild.addKeyWord(rightChild.getKeyWords()[index]);
					leftChild.getSubTree()[subTreeStartIndex++] = rightChild.getSubTree()[index];
				}
				leftChild.getSubTree()[subTreeStartIndex] = rightChild.getSubTree()[index];
				treeNode.removeKeyWord(value);
				if(treeNode == root && treeNode.getKeyWordSize() == 0) {
					leftChild.setParentNode(null);
					root = leftChild;
				}
				//递归删除
				deleteKeyWord(leftChild,key);
			}
		}
	}
	
	/**
	 * 遍历整颗B树
	 * @param treeNode
	 */
	private void searchBtree(Forfex<T> fox,TreeNode<T> treeNode) {
		int index = 0;
		if(treeNode == null) {
			return;
		}
		while(index < treeNode.getKeyWordSize()) {
			searchBtree(fox,treeNode.getSubTree()[index]);
			T originalKey = treeNode.getKeyWords()[index];
			T returnKey = fox.clip(originalKey);
			if(originalKey != returnKey) {
				throw new RuntimeException("Key Is Change");
			}
			index++;
		}
		searchBtree(fox,treeNode.getSubTree()[index]);
	}
	
	/**
	 * 查找B树中指定范围内的关键字
	 * @param lower
	 * @param upper
	 * @return
	 */
	public List<T> range(T lower,T upper) {
		List<T> rangeData = new ArrayList<>();
		if(root == null) {
			throw new RuntimeException("Root Is Null");
		}
		searchBtree(new Forfex<T>() {
			public T clip(T key) {
				if(key.compareTo(lower) >= 0 && key.compareTo(upper) < 0) {
					rangeData.add(key);
				}
				return key;
			}
			
		}, root);
		return rangeData;
	}
}
