package com.lizhenpeng.btree.core;

/**
 * 节点操作类
 * @author 出门左转
 * @param <T>
 */
public abstract class Forfex <T extends Comparable<T>>{
	public abstract T clip(T keyWord);
}
