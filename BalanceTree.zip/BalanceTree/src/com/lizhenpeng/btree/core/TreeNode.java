package com.lizhenpeng.btree.core;

import java.util.zip.Inflater;

/**
 * BTree节点
 * @author 出门左转
 *
 */
@SuppressWarnings("all")
public class TreeNode <T extends Comparable<T>>{
	
	/**
	 * 关键字数组
	 * 关键字必须实现Comparable接口,程序使用此接口来进行关键字对象的比较
	 */
	private T[] keyWords;
	
	/**
	 * 指向关键子的孩子节点
	 * 任何关键字都有左右两颗子树
	 */
	private TreeNode<T>[] subTree;
	
	/**
	 * 记录节点中实际关键字个数
	 * 由于数组长度一旦初始化不可变,因此需要记录实际的关键字数量
	 */
	private int keyWordSize = 0;
	
	/**
	 * 记录B树孩子节点的数量
	 * 由于数组长度一旦初始化不可变,因此需要记录实际的关键字数量
	 */
	private int subTreeSize = 0;
	
	/**
	 * 记录B树节点的父节点
	 * 父节点通常在子节点分裂时同时递归父节点
	 */
	private TreeNode<T> parentNode;
	
	/**
	 * 初始化节点
	 * 节点的属性根据配置类BTree确定
	 * B树的阶不可以小于2,否则B树变成一颗二叉树,因此当BTree中的不可以小于2
	 */
	public TreeNode() {
		if(BTree.Rank <= 2) {
			throw new RuntimeException("Btree Node Size Is Smaller");
		}
		keyWords = (T[]) new Comparable[BTree.keySize];
		subTree = (TreeNode<T>[]) new TreeNode[BTree.Rank];
		parentNode = null;
	}
	
	/**
	 * 判断节点是否是叶子节点
	 * B树特性是关键子有序并且任意关键字均有两颗子树
	 * 只需要判断任意一颗子树是否为空即可判断是否是叶子节点,关键字节点的增加均发生在叶子节点
	 * @return
	 */
	public boolean isLeaf() {
		return subTree[0] == null ? true : false;
	}
	
	/**
	 * 返回子树数组
	 * @return
	 */
	public TreeNode<T>[] getSubTree(){
		return subTree;
	}
	
	/**
	 * 返回关键字数组
	 * @return
	 */
	public T[] getKeyWords() {
		return keyWords;
	}
	
	/**
	 * 返回节点中的关键字数量
	 * @return
	 */
	public int getKeyWordSize() {
		return keyWordSize;
	}
	
	/**
	 * 设置该节点的父节点
	 * @param parentNode
	 */
	public void setParentNode(TreeNode<T> parentNode) {
		this.parentNode = parentNode;
	}
	
	/**
	 * 查询指定关键字的位置,如果关键字不存在返回-1
	 * @param key
	 * @return
	 */
	public int findKeyWordPosition(T key) {
		int index = 0;
		for(; index < keyWordSize; index++) {
			if(key.compareTo(keyWords[index]) == 0) {
				return index;
			}
		}
		return -1;
	}
	
	/**
	 * 判断指定的关键字是否存在
	 * @param key
	 * @return
	 */
	public boolean containKeyWord(T key) {
		return findKeyWordPosition(key) < 0 ? false : true;
	}
	
	/**
	 * 返回节点的父节点
	 * @return
	 */
	public TreeNode<T> getParentNode(){
		return parentNode;
	}
	
	/**
	 * 判断节点是否已满
	 * @return
	 */
	public boolean isFull() {
		return keyWordSize == BTree.keySize;
	}
	
	/**
	 * 关键字数组下标Index后的关键字全部向后移动一个位置
	 * 子树数组中Index+1后的节点全部移动一个位置
	 * 该方法为节点的分裂服务
	 * @param index
	 */
	public void shiftNodePosition(int index) {
		if(keyWordSize  == BTree.keySize) {
			throw new RuntimeException("The Node Is Full");
		}
		if(index < keyWordSize) {
			int endIndex = keyWordSize;
			for(; endIndex > index; endIndex--) {
				keyWords[endIndex] = keyWords[endIndex - 1];
				subTree[endIndex + 1] = subTree[endIndex];
			}
		}
		keyWordSize++;
	}
	
	/**
	 * 查询关键字在数组中可插入的位置
	 * @param key
	 * @return
	 */
	public int findPluggableIndex(T key) {
		int index = 0;
		while(index < keyWordSize && key.compareTo(keyWords[index]) > 0) {
			index++;
		}
		return index;
	}
	
	/**
	 * 从指定的位置向后移动关键字
	 * 该方法通常是为了插入一个关键字服务
	 * @param index
	 */
	public void moveKeyWords(int index) {
		if(index < 0) {
			throw new RuntimeException("Index < 0");
		}
		if(keyWordSize  == BTree.keySize) {
			throw new RuntimeException("The Node Is Full");
		}
		if(index < keyWordSize) {
			int endIndex = keyWordSize;
			for(; endIndex > index; endIndex--) {
				keyWords[endIndex] = keyWords[endIndex - 1];
			}
		}
	}
	
	/**
	 * 增加指定的关键字,如果关键字存在则失败
	 * @param key
	 * @return
	 */
	public void addKeyWord(T key) {
		if(key == null) {
			throw new RuntimeException("Key Is Null");
		}
		if(keyWordSize  == BTree.keySize) {
			throw new RuntimeException("The Node Is Full");
		}
		int findInsertPos = findPluggableIndex(key);
		moveKeyWords(findInsertPos);
		keyWords[findInsertPos] = key;
		keyWordSize++;
	}
	
	/**
	 * 节点分裂时得到左子树
	 * @return
	 */
	public TreeNode<T> clipLeftSubTree(){
		if(!isFull()) {
			throw new RuntimeException("Node Is Not Full!");
		}
		return copyTreeNode(0,BTree.middleIndex);
	}
	
	/**
	 * 节点分裂时得到右子树
	 * @return
	 */
	public TreeNode<T> clipRightSubTree(){
		if(!isFull()) {
			throw new RuntimeException("Node Is Not Full!");
		}
		return copyTreeNode(BTree.middleIndex + 1,BTree.keySize);
	}
	
	/**
	 * 复制节点指定的数据到新节点并返回新节点
	 * satrtIndex为起始位置,endIndex结束位置
	 * [startIndex,endIndex)
	 * @param startIndex
	 * @param endIndex
	 * @return
	 */
	private TreeNode<T> copyTreeNode(int startIndex,int endIndex){
		int innerIndex = 0;
		TreeNode<T> allocateSpace = new TreeNode<T>();
		for(; startIndex < endIndex; startIndex++) {
			allocateSpace.addKeyWord(keyWords[startIndex]);
			allocateSpace.getSubTree()[innerIndex] = subTree[startIndex];
			//子节点重新引用父节点
			if(subTree[startIndex] != null) {
				subTree[startIndex].setParentNode(allocateSpace);
			}
			innerIndex++;
		}
		//子节点重新引用父节点
		if(subTree[endIndex] != null) {
			subTree[endIndex].setParentNode(allocateSpace);
		}
		allocateSpace.getSubTree()[innerIndex] = subTree[endIndex];
		return allocateSpace;
	}
	
	/**
	 * 删除指定的关键字
	 * @param key
	 * @return
	 */
	public boolean removeKeyWord(T key) {
		int index = findKeyWordPosition(key);
		//节点中不包含指定的关键字
		if(index == -1) {
			return false;
		}
		if(index == keyWordSize - 1) {
			keyWords[index] = null;
			subTree[index + 1] = null;
			keyWordSize--;
			return true;
		}
		for(; index < keyWordSize -1 ;index++) {
			keyWords[index] = keyWords[index + 1];
			subTree[index + 1] = subTree[index + 2];
		}
		keyWords[keyWordSize - 1] = null;
		subTree[keyWordSize] = null;
		keyWordSize--;
		return true;
	}
	
	/**
	 * 返回关键字数组中中间节点关键字
	 * @return
	 */
	public T getMiddleKeyWord() {
		if(!isFull()) {
			throw new RuntimeException("Node Is Not Full!");
		}
		return keyWords[BTree.middleIndex];
	}
	
	/**
	 * 返回孩子节点的位置
	 * @return
	 */
	public int getSubTreePosition(TreeNode<T> child) {
		for(int index = 0; index <= keyWordSize; index++) {
			if(child == subTree[index]) {
				return index;
			}
		}
		return -1;
	}
	
	/**
	 * 节点位置整体右移
	 * @param index
	 */
	public void rightWardMove() {
		int endIndex = keyWordSize;
		for(; endIndex > 0; endIndex--) {
			keyWords[endIndex] = keyWords[endIndex - 1];
			subTree[endIndex + 1] = subTree[endIndex];
		}
		//移动第一个元素
		subTree[endIndex + 1] = subTree[endIndex];
		keyWordSize++;
	}
	
	/**
	 * 节点位置整体左移动
	 */
	public void leftWardMove() {
		int index = 0; 
		for(; index < keyWordSize -1;index++) {
			keyWords[index] = keyWords[index + 1];
			subTree[index] = subTree[index + 1];
		}
		subTree[index] = subTree[index + 1];
		keyWords[index] = null;
		subTree[index + 1] = null;
		keyWordSize--;
	}
	
}
