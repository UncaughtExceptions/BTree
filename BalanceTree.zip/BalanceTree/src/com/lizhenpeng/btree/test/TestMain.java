package com.lizhenpeng.btree.test;

import java.util.List;
import java.util.Random;

import com.lizhenpeng.btree.core.BTree;
import com.lizhenpeng.btree.core.Forfex;

public class TestMain {

	public static String getRandomString(int length) {
		String str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		Random random = new Random();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < length; i++) {
			int number = random.nextInt(62);
			sb.append(str.charAt(number));
		}
		return sb.toString();
	}

	public static Integer getRandomInteger() {
		return new Integer((int) (Math.random() * 100000));
	}

	public static void main(String[] args) {
		BTree<Integer> bTree = new BTree<Integer>();
		/**
		 * b树增加
		 */
		for (int index = 1; index <= 10; index++) {
			bTree.addKeyWord(new Integer(index));
		}
		/**
		 *  B树遍历
		 */
		bTree.search(new Forfex<Integer>() {
			public Integer clip(Integer treeNode) {
				System.out.println(treeNode);
				return treeNode;
			}
		});
		/**
		 * 获取一段范围内数据
		 * [lower,upper)
		 */
		List<Integer> range = bTree.range(new Integer(5), new Integer(10));
		/**
		 * b树高度
		 */
		System.out.println("树的高度 "+bTree.getBtreeHeight());
		/**
		 * b树删除
		 */
		for(int index = 5; index < 100; index++) {
			bTree.removeKeyWord(new Integer(index));
		}
		/**
		 * 先序遍历
		 */
		bTree.search(new Forfex<Integer>() {
			public Integer clip(Integer treeNode) {
				System.out.println(treeNode);
				return treeNode;
			}
		});
		
	}
}
